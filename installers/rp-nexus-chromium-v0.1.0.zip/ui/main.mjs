import { api, openSidePanel, openTab, openWorkspace } from '../lib/browser.mjs';
import { addProfile, deleteProfile, editProfile, getActiveProfile, makeBackup, parseBackup, projectLabel, savePreferences, selectProfile } from '../lib/model.mjs';
import { loadState, modifyState, restoreState, STORAGE_KEY } from '../lib/state.mjs';
import { BOOKMARKS, FORUM_SITE, escapeHtml as e } from '../lib/sites.mjs';
const app = document.getElementById('app');
const notice = document.getElementById('notice');
const dialog = document.getElementById('profile-dialog');
const mode = document.body.dataset.mode;
const popup = mode === 'popup';
let state;
let view = 'home';
let permissionGranted = false;
let timeout;
const NAV = [ ['home','Обзор','⌂'], ['profiles','Профили','◉'], ['sites','Сайты и доступ','↗'], ['settings','Настройки','⚙'], ['backup','Резервные копии','⇩'] ];

function feedback(message, isError = false) {
  notice.textContent = message;
  notice.className = isError ? 'error notice' : 'notice';
  clearTimeout(timeout);
  timeout = setTimeout(() => { notice.textContent = ''; notice.className = ''; }, isError ? 7000 : 4500);
}
function tag(text) { return `<span class="tag">${e(text)}</span>`; }
function profileRow(p) {
  const active = state.activeProfileId === p.id;
  return `<article class="card profile-card ${active ? 'active' : ''}"><div class="profile-title"><strong>${e(p.name)}</strong>${active ? tag('Активный') : ''}</div><p class="subtle">${e(projectLabel(p.project))} · ${e(p.server)}</p><div class="row">${!active ? `<button class="button primary" data-action="activate" data-id="${e(p.id)}">Выбрать</button>` : ''}<button class="button secondary" data-action="edit" data-id="${e(p.id)}">Изменить</button><button class="button danger" data-action="delete" data-id="${e(p.id)}" ${state.profiles.length === 1 ? 'disabled' : ''}>Удалить</button></div></article>`;
}
function sectionHome() {
  const active = getActiveProfile(state);
  return `<div class="stack"><section class="card hero"><div class="eyebrow">Активный профиль</div><h3>${e(active.name)}</h3><p>${e(projectLabel(active.project))} · ${e(active.server)}</p><div class="row" style="margin-top:17px"><button class="button" data-action="edit" data-id="${e(active.id)}">Настроить профиль</button>${active.forumUrl ? `<button class="button" data-url="${e(active.forumUrl)}">Открыть форум ↗</button>` : ''}</div></section><div class="grid"><section class="card"><p class="eyebrow">Профили</p><div class="stat">${state.profiles.length}</div><p class="subtle">Отдельные RP-проекты и серверы</p><button class="button secondary" data-action="nav" data-view="profiles">Управлять профилями</button></section><section class="card"><p class="eyebrow">Интеграция с форумом</p><div class="stat">${permissionGranted ? 'Включена' : 'Выключена'}</div><p class="subtle">Кнопка RP Nexus на официальном форуме Majestic RP</p><button class="button secondary" data-action="nav" data-view="sites">Настроить доступ</button></section></div><section class="card"><h3>Быстрый доступ</h3><p class="subtle">Переход на сайты без автоматического сбора данных</p><div class="row">${BOOKMARKS.map(link => `<button class="button secondary" data-url="${e(link.url)}">${e(link.name)} ↗</button>`).join('')}</div></section></div>`;
}
function sectionProfiles() {
  return `<div class="stack"><div class="row spread"><p class="lead">Храните разные игровые профили локально. Сервер и ссылка на форум задаются отдельно.</p><button class="button primary" data-action="create">+ Новый профиль</button></div>${state.profiles.map(profileRow).join('')}</div>`;
}
function sectionSites() {
  return `<div class="stack"><section class="card"><div class="row spread"><h3>Встраивание в форум Majestic RP</h3><span class="site-status ${permissionGranted ? 'on' : 'off'}">${permissionGranted ? '● Доступ предоставлен' : '○ Доступ выключен'}</span></div><p class="lead">${e(FORUM_SITE.description)}</p><p class="subtle">Домен: forum.majestic-rp.ru. Доступ запрашивается только по нажатию кнопки и может быть отозван в любой момент.</p><div class="row"><button class="button ${permissionGranted ? 'danger' : 'primary'}" data-action="permission">${permissionGranted ? 'Отозвать доступ' : 'Разрешить на сайте'}</button><button class="button secondary" data-url="${e(FORUM_SITE.url)}">Открыть форум ↗</button></div></section><h3>Разрешённые сайты и закладки</h3>${BOOKMARKS.map(x => `<div class="card link-card"><div><h3>${e(x.name)}</h3><p class="subtle">${e(x.detail)}</p></div><button class="button secondary" data-url="${e(x.url)}">Открыть ↗</button></div>`).join('')}<div class="card"><h3>Конфиденциальность</h3><p class="lead">Fletcher Wiki, Docossum, Google Docs и Sheets открываются как обычные сайты. RP Nexus 0.1.0 не считывает с них данные, не получает файлы и не отправляет запросы от вашего имени.</p></div></div>`;
}
function sectionSettings() {
  const p = state.preferences;
  return `<section class="card stack"><div class="control"><div><h3>Тема интерфейса</h3><p class="subtle">Влияет на popup, боковую панель и рабочее пространство</p></div><select aria-label="Тема" data-setting="theme"><option value="system" ${p.theme === 'system' ? 'selected' : ''}>Системная</option><option value="light" ${p.theme === 'light' ? 'selected' : ''}>Светлая</option><option value="dark" ${p.theme === 'dark' ? 'selected' : ''}>Тёмная</option></select></div><div class="divider"></div><div class="control"><div><h3>Начальный раздел</h3><p class="subtle">Выбирается при новом открытии расширения</p></div><select aria-label="Стартовый экран" data-setting="startPage">${NAV.map(([id,label]) => `<option value="${id}" ${p.startPage === id ? 'selected' : ''}>${e(label)}</option>`).join('')}</select></div><div class="divider"></div><div class="control"><div><h3>Компактный интерфейс</h3><p class="subtle">Уменьшает отступы в карточках</p></div><label class="check"><input type="checkbox" data-setting="compact" ${p.compact ? 'checked' : ''}><span>Включить</span></label></div></section>`;
}
function sectionBackup() {
  return `<div class="stack"><section class="card"><h3>Скачать резервную копию</h3><p class="lead">JSON-файл с профилями, активным сервером и настройками. Авторизационные данные сайтов и содержимое страниц не сохраняются.</p><div class="row" style="margin-top:14px"><button class="button primary" data-action="export">Скачать JSON</button></div></section><section class="card"><h3>Восстановить из файла</h3><p class="lead">Данные проверяются до применения. Импорт заменит текущие профили и настройки. Максимальный размер — 1 МиБ.</p><div style="margin-top:14px"><label class="field">Выберите .json<input id="backup-file" type="file" accept=".json,application/json"></label></div></section><section class="card"><h3>Где хранятся данные</h3><p class="lead">В локальном хранилище браузерного расширения. RP Nexus не имеет аккаунта, собственного сервера и телеметрии. Перед удалением расширения скачайте копию.</p></section></div>`;
}
const titles = {home:['Обзор','Рабочая среда под ваши RP-проекты'],profiles:['Профили','Переключение между игровыми серверами'],sites:['Сайты и разрешения','Вы контролируете, где работает расширение'],settings:['Настройки','Настройте интерфейс под себя'],backup:['Резервные копии','Перенос данных между браузерами']};
function renderPopup() {
  const p = getActiveProfile(state);
  return `<div class="popup-shell stack"><div class="brand"><span class="logo">RN</span><div><h1>RP Nexus</h1><p>Версия 0.1.0</p></div></div><div class="card stack"><div class="row spread"><strong>Активный профиль</strong>${tag(projectLabel(p.project))}</div><select aria-label="Выбрать профиль" id="popup-profile">${state.profiles.map(x => `<option value="${e(x.id)}" ${x.id === state.activeProfileId ? 'selected' : ''}>${e(x.name)} · ${e(x.server)}</option>`).join('')}</select><p class="subtle">${e(p.server)}</p>${p.forumUrl ? `<button class="button secondary" data-url="${e(p.forumUrl)}">Открыть форум ↗</button>` : ''}</div><div class="row"><button class="button primary" data-action="panel">Боковая панель</button><button class="button secondary" data-action="workspace">Рабочее пространство ↗</button></div><div class="row"><button class="button link" data-action="popup-settings">Настройки и профили</button><button class="button link" data-url="https://docossum.com/">Docossum ↗</button><button class="button link" data-url="https://fletcher-wiki.com/">Fletcher ↗</button></div></div>`;
}
function render() {
  if (!state) return;
  document.documentElement.dataset.theme = state.preferences.theme;
  document.body.dataset.compact = String(state.preferences.compact);
  if (popup) { app.innerHTML = renderPopup(); return; }
  const title = titles[view];
  const contents = { home: sectionHome, profiles: sectionProfiles, sites: sectionSites, settings: sectionSettings, backup: sectionBackup };
  app.innerHTML = `<div class="layout"><aside class="side"><div class="brand"><div class="logo">RN</div><div><h1>RP Nexus</h1><p>Версия 0.1.0</p></div></div><nav class="nav" aria-label="Разделы">${NAV.map(([id, label, icon]) => `<button type="button" data-action="nav" data-view="${id}" class="${view === id ? 'active' : ''}" ${view === id ? 'aria-current="page"' : ''}><span aria-hidden="true">${icon}</span>${e(label)}</button>`).join('')}</nav><div class="side-footer">Локальные данные · Без облачной регистрации</div></aside><main class="main"><header class="topline"><div><p class="eyebrow">RP Nexus / ${e(title[0])}</p><h2>${e(title[0])}</h2><p class="lead">${e(title[1])}</p></div>${mode === 'sidebar' ? '' : '<span class="tag">v0.1.0</span>'}</header>${contents[view]()}</main></div>`;
}
async function refreshPermission() {
  try { permissionGranted = await api.permissions.contains({ origins: [FORUM_SITE.origin] }); }
  catch { permissionGranted = false; }
}
function openEditor(id) {
  if (!dialog) return;
  const p = id ? state.profiles.find(x => x.id === id) : null;
  if (id && !p) throw new Error('Профиль не найден');
  const form = document.getElementById('profile-form');
  form.reset();
  form.elements.namedItem('profileId').value = p?.id ?? '';
  form.elements.namedItem('name').value = p?.name ?? '';
  form.elements.namedItem('project').value = p?.project ?? 'majestic';
  form.elements.namedItem('server').value = p?.server === 'Не выбран' ? '' : p?.server ?? '';
  form.elements.namedItem('forumUrl').value = p?.forumUrl ?? '';
  document.getElementById('dialog-title').textContent = p ? 'Изменить профиль' : 'Создать профиль';
  dialog.showModal();
  form.elements.namedItem('name').focus();
}
function exportBackup() {
  const text = makeBackup(state);
  const blob = new Blob([text], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `rp-nexus-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
  feedback('Резервная копия подготовлена');
}
async function changePermission() {
  // The permission request starts within the user gesture, without unrelated awaits.
  if (!permissionGranted) {
    const granted = await api.permissions.request({ origins: [FORUM_SITE.origin] });
    if (!granted) { feedback('Разрешение не предоставлено', true); return; }
    try {
      const found = await api.scripting.getRegisteredContentScripts({ ids: ['rp-nexus-majestic-launcher-v1'] });
      if (!found.length) await api.scripting.registerContentScripts([{ id: 'rp-nexus-majestic-launcher-v1', matches: [FORUM_SITE.origin], js: ['content/launcher.js'], runAt: 'document_idle', allFrames: false, persistAcrossSessions: true }]);
    } catch (err) {
      // The background might have registered the script simultaneously. Verify before failing.
      const found = await api.scripting.getRegisteredContentScripts({ ids: ['rp-nexus-majestic-launcher-v1'] });
      if (!found.length) { await api.permissions.remove({ origins: [FORUM_SITE.origin] }); throw err; }
    }
    feedback('Доступ предоставлен. Обновите вкладку форума для появления кнопки.');
  } else {
    await api.permissions.remove({ origins: [FORUM_SITE.origin] });
    try { await api.scripting.unregisterContentScripts({ ids: ['rp-nexus-majestic-launcher-v1'] }); } catch { /* Background also unregisters */ }
    feedback('Разрешение отозвано. Обновите страницу форума.');
  }
  await refreshPermission(); render();
}
async function executeAction(button) {
  if (button.dataset.url) { await openTab(button.dataset.url); return; }
  const { action, id } = button.dataset;
  if (action === 'nav') { view = button.dataset.view; render(); return; }
  if (action === 'create') { openEditor(null); return; }
  if (action === 'edit') { openEditor(id); return; }
  if (action === 'close-dialog') { dialog.close(); return; }
  if (action === 'activate') { state = await modifyState(s => selectProfile(s, id)); feedback('Активный профиль изменён'); render(); return; }
  if (action === 'delete') {
    const p = state.profiles.find(x => x.id === id);
    if (!p) return;
    if (!confirm(`Удалить профиль «${p.name}»? Это действие нельзя отменить без резервной копии.`)) return;
    state = await modifyState(s => deleteProfile(s, id)); feedback('Профиль удалён'); render(); return;
  }
  if (action === 'permission') { await changePermission(); return; }
  if (action === 'export') { exportBackup(); return; }
  if (action === 'panel') { await openSidePanel(); return; }
  if (action === 'workspace' || action === 'popup-settings') { await openWorkspace(); return; }
}
document.addEventListener('click', event => {
  const button = event.target.closest('button[data-action],button[data-url]');
  if (!button || button.disabled) return;
  void executeAction(button).catch(err => feedback(err?.message || 'Ошибка выполнения операции', true));
});
document.addEventListener('change', event => {
  const el = event.target;
  if (el.id === 'popup-profile') {
    void modifyState(s => selectProfile(s, el.value)).then(next => { state = next; render(); feedback('Профиль выбран'); }).catch(err => feedback(err.message, true));
  } else if (el.dataset.setting) {
    const value = el.type === 'checkbox' ? el.checked : el.value;
    void modifyState(s => savePreferences(s, { [el.dataset.setting]: value })).then(next => { state = next; render(); feedback('Настройки сохранены'); }).catch(err => feedback(err.message, true));
  } else if (el.id === 'backup-file' && el.files?.[0]) {
    const file = el.files[0];
    if (file.size > 1024 * 1024) { feedback('Файл больше 1 МиБ', true); el.value = ''; return; }
    void file.text().then(text => {
      const restored = parseBackup(text);
      if (!confirm(`Заменить текущие данные? В копии профилей: ${restored.profiles.length}.`)) return;
      return restoreState(restored).then(next => { state = next; view = state.preferences.startPage; render(); feedback('Резервная копия восстановлена'); });
    }).catch(err => feedback(err.message, true)).finally(() => { if (el.isConnected) el.value = ''; });
  }
});
document.addEventListener('submit', event => {
  if (event.target.id !== 'profile-form') return;
  event.preventDefault();
  const f = event.target.elements;
  const id = f.namedItem('profileId').value;
  const data = { name: f.namedItem('name').value, project: f.namedItem('project').value, server: f.namedItem('server').value, forumUrl: f.namedItem('forumUrl').value };
  void modifyState(s => id ? editProfile(s, id, data) : addProfile(s, data)).then(next => { state = next; dialog.close(); render(); feedback(id ? 'Профиль обновлён' : 'Профиль создан'); }).catch(err => feedback(err.message, true));
});
api.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes[STORAGE_KEY]?.newValue) return;
  void loadState().then(next => { state = next; render(); }).catch(err => feedback(err.message, true));
});
api.permissions.onAdded.addListener(() => { void refreshPermission().then(render); });
api.permissions.onRemoved.addListener(() => { void refreshPermission().then(render); });
try { state = await loadState(); await refreshPermission(); view = state.preferences.startPage; render(); }
catch (err) { app.textContent = `Не удалось открыть данные RP Nexus: ${err.message}. Данные не удалены. Для восстановления проверьте настройки расширения.`; feedback(err.message, true); }
